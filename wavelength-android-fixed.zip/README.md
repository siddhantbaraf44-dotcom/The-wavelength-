# Wavelength Android app
WebView wrapper for https://thewavelength.netlify.app with FCM push notifications.
Pushes are sent by the Cloudflare Worker in `worker/index.js`.

Build: upload this zip (or its contents) to a GitHub repo with `.github/workflows/build.yml`, then Actions -> Build APK -> Run workflow.
The APK appears under Releases (and Artifacts).
