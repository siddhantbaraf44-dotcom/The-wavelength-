// Cloudflare Worker: sends FCM pushes for new Wavelength messages (free, no Firebase Blaze needed)
const PROJECT = "siddhant-bandu-baraf";
const DB = `https://${PROJECT}-default-rtdb.firebaseio.com`;
const ALLOWED_ORIGIN = "https://thewavelength.netlify.app";
const SAFE_KEY = /^[^.$#\[\]\/\s]+$/;

const cors = {
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function b64url(data) {
  const bytes = data instanceof ArrayBuffer ? new Uint8Array(data) : data;
  let s = "";
  bytes.forEach((b) => (s += String.fromCharCode(b)));
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

let cached = { token: null, exp: 0 };

async function getAccessToken(env) {
  const now = Math.floor(Date.now() / 1000);
  if (cached.token && cached.exp - 60 > now) return cached.token;

  const sa = JSON.parse(env.SERVICE_ACCOUNT);
  const enc = (o) => b64url(new TextEncoder().encode(JSON.stringify(o)));
  const unsigned =
    enc({ alg: "RS256", typ: "JWT" }) +
    "." +
    enc({
      iss: sa.client_email,
      scope:
        "https://www.googleapis.com/auth/firebase.messaging https://www.googleapis.com/auth/firebase.database https://www.googleapis.com/auth/userinfo.email",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600,
    });

  const pem = sa.private_key.replace(/-----[^-]+-----/g, "").replace(/\s/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "pkcs8",
    der,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned));

  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: unsigned + "." + b64url(sig),
    }),
  });
  const j = await r.json();
  if (!j.access_token) throw new Error("token error: " + JSON.stringify(j));
  cached = { token: j.access_token, exp: now + (j.expires_in || 3600) };
  return cached.token;
}

const dbGet = async (path, tok) =>
  (await fetch(`${DB}/${path}.json?access_token=${tok}`)).json();

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return new Response("ok", { headers: cors });

    try {
      const { chatId, msgId } = await request.json();
      if (!SAFE_KEY.test(chatId || "") || !SAFE_KEY.test(msgId || "")) {
        return new Response("bad request", { status: 400, headers: cors });
      }

      const tok = await getAccessToken(env);

      // Verify the message really exists, is fresh, and wasn't already notified
      const msg = await dbGet(`chats/${chatId}/messages/${msgId}`, tok);
      if (!msg || msg.sender === "system" || msg.notified) return new Response("skip", { headers: cors });
      if (Date.now() - (msg.time || 0) > 300000) return new Response("old", { headers: cors });
      await fetch(`${DB}/chats/${chatId}/messages/${msgId}.json?access_token=${tok}`, {
        method: "PATCH",
        body: JSON.stringify({ notified: true }),
      });

      // Who should get it
      const meta = (await dbGet(`chats/${chatId}/meta`, tok)) || {};
      let members = Object.keys(meta.members || {});
      if (!members.length && chatId.startsWith("dm__")) members = chatId.split("__").slice(1);
      const recipients = members.filter((m) => m !== msg.sender);

      const isDm = meta.type === "dm" || chatId.startsWith("dm__");
      const senderName = msg.senderName || msg.sender || "Someone";
      const text = msg.sticker && !msg.text ? "Sent a sticker" : String(msg.text || "New message");
      const title = isDm ? senderName : meta.name || "Group";
      const body = (isDm ? text : `${senderName}: ${text}`).slice(0, 200);

      const report = [];
      for (const user of recipients) {
        if (!SAFE_KEY.test(user)) continue;
        const tokens = Object.keys((await dbGet(`users/${user}/fcmTokens`, tok)) || {});
        if (!tokens.length) report.push(`${user}: NO TOKENS`);
        for (const t of tokens) {
          const res = await fetch(`https://fcm.googleapis.com/v1/projects/${PROJECT}/messages:send`, {
            method: "POST",
            headers: { Authorization: `Bearer ${tok}`, "Content-Type": "application/json" },
            body: JSON.stringify({
              message: { token: t, data: { chatId, title, body }, android: { priority: "HIGH" } },
            }),
          });
          report.push(`${user}: FCM ${res.status}${res.ok ? "" : " " + (await res.text()).slice(0, 300)}`);
          if (res.status === 404) {
            await fetch(`${DB}/users/${user}/fcmTokens/${encodeURIComponent(t)}.json?access_token=${tok}`, {
              method: "DELETE",
            });
          }
        }
      }
      return new Response("sent | " + (report.join(" ; ") || "no recipients"), { headers: cors });
    } catch (e) {
      return new Response("error: " + e.message, { status: 500, headers: cors });
    }
  },
};
