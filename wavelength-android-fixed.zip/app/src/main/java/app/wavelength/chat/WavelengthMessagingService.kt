package app.wavelength.chat

import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class WavelengthMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        TokenRegistrar.registerToken(applicationContext, token)
    }

    override fun onMessageReceived(msg: RemoteMessage) {
        val chatId = msg.data["chatId"] ?: return
        val title = msg.data["title"] ?: "Wavelength"
        val body = msg.data["body"] ?: ""

        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("chatId", chatId)
        val pending = PendingIntent.getActivity(
            this, chatId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(this, MainActivity.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        try {
            NotificationManagerCompat.from(this).notify(chatId.hashCode(), notif) // one per chat
        } catch (e: SecurityException) {
            // notification permission not granted
        }
    }
}
