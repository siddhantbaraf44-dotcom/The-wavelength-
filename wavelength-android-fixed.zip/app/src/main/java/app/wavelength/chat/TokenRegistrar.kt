package app.wavelength.chat

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessaging

/** Saves/removes this device's FCM token at users/{username}/fcmTokens/{token}. */
object TokenRegistrar {
    private const val DB_URL = "https://siddhant-bandu-baraf-default-rtdb.firebaseio.com"
    private const val PREFS = "wavelength"
    private const val KEY_USER = "username"

    private fun db() = FirebaseDatabase.getInstance(DB_URL)

    fun savedUser(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_USER, null)

    private fun toast(ctx: Context, msg: String) {
        Log.d("Wavelength", msg)
        Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
    }

    private val SAFE = Regex("^[^.$#\\[\\]/\\s]+$")

    fun register(ctx: Context, username: String) {
        if (!SAFE.matches(username)) { toast(ctx, "Push: bad username"); return }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_USER, username).apply()
        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                db().getReference("users/$username/fcmTokens/$token").setValue(true)
                    .addOnSuccessListener { toast(ctx, "Push registered for $username") }
                    .addOnFailureListener { toast(ctx, "Token save failed: ${it.message}") }
            }
            .addOnFailureListener { toast(ctx, "FCM token failed: ${it.message}") }
    }

    fun registerToken(ctx: Context, token: String) {
        val user = savedUser(ctx) ?: return
        db().getReference("users/$user/fcmTokens/$token").setValue(true)
    }

    fun unregister(ctx: Context, username: String) {
        if (!SAFE.matches(username)) return
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY_USER).apply()
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            db().getReference("users/$username/fcmTokens/$token").removeValue()
        }
    }
}
