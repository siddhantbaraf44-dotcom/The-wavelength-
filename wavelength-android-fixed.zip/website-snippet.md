# Changes to your website (index.html)

## A. Register the device (only does something inside the Android app)

1. In `loginSuccess(...)`, after `localStorage.setItem("wavelength_user", ...)`:
```js
if (window.AndroidBridge) AndroidBridge.registerUser(currentUser.username);
```
2. In the saved-session block near the bottom, right after `initApp();`:
```js
if (window.AndroidBridge) AndroidBridge.registerUser(currentUser.username);
```
3. On logout, BEFORE clearing currentUser:
```js
if (window.AndroidBridge && currentUser) AndroidBridge.unregisterUser(currentUser.username);
```

## B. Tell the Worker about each new message

Add this helper anywhere in your module script (replace the URL with your Worker's URL):
```js
const PUSH_URL = "https://wavelength-push.YOURNAME.workers.dev";
function notifyPush(chatId, msgId) {
  try {
    fetch(PUSH_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chatId, msgId }),
      keepalive: true,
    }).catch(() => {});
  } catch (e) {}
}
```

In `sendMessage()` change
```js
await push(msgRef, newMsg);
```
to
```js
const pushed = await push(msgRef, newMsg);
notifyPush(activeChatId, pushed.key);
```

In `sendSticker()` change
```js
await push(ref(db, `chats/${activeChatId}/messages`), newMsg);
```
to
```js
const pushed = await push(ref(db, `chats/${activeChatId}/messages`), newMsg);
notifyPush(activeChatId, pushed.key);
```
